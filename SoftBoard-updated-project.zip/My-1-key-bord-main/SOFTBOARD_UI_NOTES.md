# SoftBoard UI update

This project snapshot adds a SoftBoard-branded settings experience.

## UI changes
- Adds a SoftBoard Home dashboard with a keyboard preview, quick links, and a "Made by Yashi" credit.
- Adds a Tools page linking to the existing Toolbar, Text correction, Dictionaries, Layouts, Gesture typing, and Advanced settings.
- Adds a persistent Home / Themes / Tools / Settings bottom navigation for the four top-level destinations.
- Uses the existing Appearance screen for Themes and preserves the existing settings screens and keyboard preferences.
- Renames the app label and settings title to SoftBoard.

## Files changed
- `app/src/main/java/helium314/keyboard/settings/SettingsNavHost.kt`
- `app/src/main/java/helium314/keyboard/settings/screens/SoftBoardScreens.kt` (new)
- `app/src/main/res/values/strings.xml`
- `app/src/main/res/values/donottranslate.xml`

## Build check
The Gradle wrapper could not download Gradle in this environment because network access to `services.gradle.org` was unavailable. Please open the project in Android Studio and run a Gradle sync/build to verify against your local Android SDK.
