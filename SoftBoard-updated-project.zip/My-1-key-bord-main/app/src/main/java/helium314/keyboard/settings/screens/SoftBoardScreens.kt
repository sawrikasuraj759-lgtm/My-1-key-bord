// SPDX-License-Identifier: GPL-3.0-only
package helium314.keyboard.settings.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import helium314.keyboard.latin.utils.Theme
import helium314.keyboard.latin.utils.previewDark

private val SoftBackground = Color(0xFF100B18)
private val SoftCard = Color(0xFF21172D)
private val SoftPurple = Color(0xFFB56CFF)
private val SoftPink = Color(0xFFFF75C8)
private val SoftMuted = Color(0xFFBDAFCB)
private val SoftWhite = Color(0xFFFFF8FF)

@Composable
fun SoftBoardHomeScreen(
    onClickThemes: () -> Unit,
    onClickLanguages: () -> Unit,
    onClickTools: () -> Unit,
    onClickSettings: () -> Unit,
    onClickAbout: () -> Unit,
) {
    Scaffold(
        containerColor = SoftBackground,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { insets ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(insets)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(
                            Brush.linearGradient(listOf(SoftPurple, SoftPink)),
                            RoundedCornerShape(17.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⌨", color = Color.White, fontSize = 27.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("SoftBoard", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Your keyboard, your style", color = SoftMuted, fontSize = 12.sp)
                }
                Text("✦", color = SoftPink, fontSize = 25.sp)
            }

            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("HELLO, WELCOME BACK", color = SoftPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Make typing beautiful.", color = SoftWhite, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Personalize your keyboard with themes, tools and smart settings.", color = SoftMuted, fontSize = 13.sp, lineHeight = 19.sp)
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SoftCard),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Color(0xFF39204F), Color(0xFF21172D))))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(13.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("YOUR KEYBOARD", color = SoftMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                            Text("SoftBoard", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("💜", fontSize = 30.sp)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("Q","W","E","R","T","Y","U","I","O","P").forEach { KeyboardKey(it, Modifier.weight(1f)) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                            listOf("A","S","D","F","G","H","J","K","L").forEach { KeyboardKey(it, Modifier.weight(1f)) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp)) {
                            listOf("Z","X","C","V","B","N","M").forEach { KeyboardKey(it, Modifier.weight(1f)) }
                        }
                    }
                    Text("MADE BY YASHI", color = SoftPink, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
            }

            Text("EXPLORE SOFTBOARD", color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                FeatureCard("🎨", "Themes", "Colors & styles", onClickThemes, Modifier.weight(1f))
                FeatureCard("🧰", "Tools", "Useful shortcuts", onClickTools, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                FeatureCard("🌐", "Languages", "Layouts & input", onClickLanguages, Modifier.weight(1f))
                FeatureCard("⚙️", "Settings", "Make it yours", onClickSettings, Modifier.weight(1f))
            }

            Surface(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onClickAbout),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF1B1424)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("♡", color = SoftPink, fontSize = 22.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Made with love", color = SoftWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("SoftBoard • Made by Yashi", color = SoftMuted, fontSize = 11.sp)
                    }
                    Text("›", color = SoftPurple, fontSize = 25.sp)
                }
            }
        }
    }
}

@Composable
private fun KeyboardKey(label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.height(31.dp).background(Color(0xFF59406C), RoundedCornerShape(7.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = SoftWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FeatureCard(
    icon: String,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = SoftCard)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(icon, fontSize = 24.sp)
            Text(title, color = SoftWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = SoftMuted, fontSize = 11.sp)
        }
    }
}

@Composable
fun SoftBoardToolsScreen(
    onClickToolbar: () -> Unit,
    onClickCorrection: () -> Unit,
    onClickDictionaries: () -> Unit,
    onClickLayouts: () -> Unit,
    onClickGesture: () -> Unit,
    onClickAdvanced: () -> Unit,
) {
    Scaffold(containerColor = SoftBackground, contentWindowInsets = WindowInsets.safeDrawing) { insets ->
        Column(
            modifier = Modifier.fillMaxSize().padding(insets).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("SoftBoard", color = SoftPurple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Your Tools", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("Everything you need for a smoother typing experience.", color = SoftMuted, fontSize = 13.sp)
            ToolRow("⌨️", "Toolbar", "Customize your keyboard toolbar", onClickToolbar)
            ToolRow("✍️", "Text correction", "Suggestions and auto-correction", onClickCorrection)
            ToolRow("📚", "Dictionaries", "Manage your language dictionaries", onClickDictionaries)
            ToolRow("🌐", "Layouts", "Choose secondary keyboard layouts", onClickLayouts)
            ToolRow("👆", "Gesture typing", "Configure swipe typing", onClickGesture)
            ToolRow("🛠️", "Advanced", "More keyboard controls", onClickAdvanced)
            Spacer(Modifier.height(8.dp))
            Text("MADE BY YASHI  ✦", color = SoftPink, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
    }
}

@Composable
private fun ToolRow(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        color = SoftCard
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(43.dp).background(Color(0xFF382448), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 21.sp) }
            Spacer(Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = SoftWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = SoftMuted, fontSize = 11.sp)
            }
            Text("›", color = SoftPurple, fontSize = 25.sp)
        }
    }
}
